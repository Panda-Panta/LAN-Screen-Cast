// Package rtp contains the RTP static source.
package rtp

import (
	"fmt"
	"net"
	"net/url"
	"time"

	"github.com/bluenviron/gortsplib/v5/pkg/description"
	"github.com/bluenviron/gortsplib/v5/pkg/rtptime"
	"github.com/bluenviron/gortsplib/v5/pkg/sdpunmarshaler"
	"github.com/pion/rtp"

	"github.com/bluenviron/mediamtx/internal/conf"
	"github.com/bluenviron/mediamtx/internal/counterdumper"
	"github.com/bluenviron/mediamtx/internal/defs"
	"github.com/bluenviron/mediamtx/internal/errordumper"
	"github.com/bluenviron/mediamtx/internal/logger"
	"github.com/bluenviron/mediamtx/internal/packetdumper"
	"github.com/bluenviron/mediamtx/internal/protocols/udp"
	"github.com/bluenviron/mediamtx/internal/protocols/unix"
	"github.com/bluenviron/mediamtx/internal/stream"
	"github.com/bluenviron/mediamtx/internal/unit"
)

type parent interface {
	logger.Writer
	SetReady(req defs.PathSourceStaticSetReadyReq) defs.PathSourceStaticSetReadyRes
	SetNotReady(req defs.PathSourceStaticSetNotReadyReq)
}

// Source is a RTP static source.
type Source struct {
	DumpPackets       bool
	ReadTimeout       conf.Duration
	UDPReadBufferSize uint
	Parent            parent
}

// Log implements logger.Writer.
func (s *Source) Log(level logger.Level, format string, args ...any) {
	s.Parent.Log(level, "[RTP source] "+format, args...)
}

// Info returns runtime information.
func (*Source) Info() defs.StaticSourceInfo {
	return defs.StaticSourceInfo{}
}

// Run implements StaticSource.
func (s *Source) Run(params defs.StaticSourceRunParams) error {
	sd, err := sdpunmarshaler.Unmarshal([]byte(params.Conf.RTPSDP))
	if err != nil {
		return err
	}

	var desc description.Session
	err = desc.Unmarshal2(sd)
	if err != nil {
		return err
	}

	s.Log(logger.Debug, "connecting")

	u, err := url.Parse(params.ResolvedSource)
	if err != nil {
		return err
	}

	var nc net.Conn

	switch u.Scheme {
	case "unix+rtp": // deprecated
		params := unix.URLToParams(u)
		l := &unix.Listener{
			Path:   params.Path,
			Listen: net.Listen,
		}
		err = l.Initialize()
		if err != nil {
			return err
		}
		nc = l

	default:
		udpReadBufferSize := s.UDPReadBufferSize
		if params.Conf.RTPUDPReadBufferSize != nil {
			udpReadBufferSize = *params.Conf.RTPUDPReadBufferSize
		}

		params := udp.URLToParams(u)
		l := &udp.Listener{
			Address:           params.Address,
			Source:            params.Source,
			IntfName:          params.IntfName,
			UDPReadBufferSize: int(udpReadBufferSize),
		}

		l.ListenPacket = func(network, address string) (net.PacketConn, error) {
			pc, err2 := net.ListenPacket(network, address)
			if err2 != nil {
				return nil, err2
			}

			if s.DumpPackets {
				pc2 := &packetdumper.PacketConn{
					Wrapped: pc,
					Prefix:  "rtp_source_packet_conn",
				}
				err2 = pc2.Initialize()
				if err2 != nil {
					pc.Close() //nolint:errcheck
					return nil, err2
				}

				pc = pc2
			}

			return pc, nil
		}

		err = l.Initialize()
		if err != nil {
			return err
		}
		nc = l
	}

	readerErr := make(chan error)
	go func() {
		readerErr <- s.runReader(&desc, nc)
	}()

	for {
		select {
		case err = <-readerErr:
			nc.Close()
			return err

		case <-params.ReloadConf:

		case <-params.Context.Done():
			nc.Close()
			<-readerErr
			return fmt.Errorf("terminated")
		}
	}
}

func (s *Source) runReader(desc *description.Session, nc net.Conn) error {
	packetsLost := &counterdumper.Dumper{
		OnReport: func(val uint64) {
			s.Log(logger.Warn, "%d RTP %s lost",
				val,
				func() string {
					if val == 1 {
						return "packet"
					}
					return "packets"
				}())
		},
	}

	packetsLost.Start()
	defer packetsLost.Stop()

	decodeErrors := &errordumper.Dumper{
		OnReport: func(val uint64, last error) {
			if val == 1 {
				s.Log(logger.Warn, "decode error: %v", last)
			} else {
				s.Log(logger.Warn, "%d decode errors, last was: %v", val, last)
			}
		},
	}
	decodeErrors.Start()
	defer decodeErrors.Stop()

	var subStream *stream.SubStream

	timeDecoder := &rtptime.GlobalDecoder{}
	timeDecoder.Initialize()

	mediasByPayloadType := make(map[uint8]*rtpMedia)
	formatsByPayloadType := make(map[uint8]*rtpFormat)

	for _, descMedia := range desc.Medias {
		rtpMedia := &rtpMedia{
			desc: descMedia,
		}

		for _, descFormat := range descMedia.Formats {
			rtpFormat := &rtpFormat{
				desc: descFormat,
			}
			rtpFormat.initialize()

			mediasByPayloadType[descFormat.PayloadType()] = rtpMedia
			formatsByPayloadType[descFormat.PayloadType()] = rtpFormat
		}
	}

	for {
		buf := make([]byte, 1500)
		nc.SetReadDeadline(time.Now().Add(time.Duration(s.ReadTimeout)))
		n, err := nc.Read(buf)
		if err != nil {
			return err
		}

		var pkt rtp.Packet
		err = pkt.Unmarshal(buf[:n])
		if err != nil {
			if subStream != nil {
				decodeErrors.Add(err)
				continue
			}
			return err
		}

		if subStream == nil {
			res := s.Parent.SetReady(defs.PathSourceStaticSetReadyReq{
				Desc:          desc,
				UseRTPPackets: true,
				ReplaceNTP:    true,
			})
			if res.Err != nil {
				return res.Err
			}

			defer s.Parent.SetNotReady(defs.PathSourceStaticSetNotReadyReq{})

			subStream = res.SubStream
		}

		media, ok := mediasByPayloadType[pkt.PayloadType]
		if !ok {
			continue
		}

		forma := formatsByPayloadType[pkt.PayloadType]

		pkts, lost := forma.rtpReceiver.ProcessPacket2(&pkt, time.Now(), forma.desc.PTSEqualsDTS(&pkt))

		if lost != 0 {
			packetsLost.Add(lost)
		}

		for _, pkt := range pkts {
			pts, ok2 := timeDecoder.Decode(forma.desc, pkt)
			if !ok2 {
				continue
			}

			subStream.WriteUnit(media.desc, forma.desc, &unit.Unit{
				PTS:        pts,
				RTPPackets: []*rtp.Packet{pkt},
			})
		}
	}
}

// APISourceDescribe implements StaticSource.
func (*Source) APISourceDescribe() *defs.APIPathSource {
	return &defs.APIPathSource{
		Type: defs.APIPathSourceTypeRTPSource,
		ID:   "",
	}
}
