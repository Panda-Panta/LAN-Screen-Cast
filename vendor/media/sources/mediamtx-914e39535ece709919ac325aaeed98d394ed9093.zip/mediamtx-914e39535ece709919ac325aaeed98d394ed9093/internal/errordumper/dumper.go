// Package errordumper contains a counter that that periodically invokes a callback if the counter is not zero.
package errordumper

import (
	"sync"
	"time"
)

const (
	callbackPeriod = 1 * time.Second
)

// Dumper is a counter that periodically invokes a callback if errors were added.
type Dumper struct {
	OnReport func(v uint64, last error)

	mutex      sync.Mutex
	counter    uint64
	absCounter uint64
	last       error

	terminate chan struct{}
	done      chan struct{}
}

// Start starts the counter.
func (c *Dumper) Start() {
	c.terminate = make(chan struct{})
	c.done = make(chan struct{})

	go c.run()
}

// Stop stops the counter.
func (c *Dumper) Stop() {
	close(c.terminate)
	<-c.done
}

// Add adds an error to the counter.
func (c *Dumper) Add(err error) {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	c.counter++
	c.absCounter++
	c.last = err
}

// Get returns the total number of errors.
func (c *Dumper) Get() uint64 {
	c.mutex.Lock()
	defer c.mutex.Unlock()
	return c.absCounter
}

func (c *Dumper) run() {
	defer close(c.done)

	t := time.NewTicker(callbackPeriod)
	defer t.Stop()

	for {
		select {
		case <-c.terminate:
			return

		case <-t.C:
			c.mutex.Lock()
			var counter uint64
			counter, c.counter = c.counter, 0
			last := c.last
			c.mutex.Unlock()

			if counter != 0 {
				c.OnReport(counter, last)
			}
		}
	}
}
