package httpp3_test

import (
	"crypto/tls"
	"io"
	"net/http"
	"testing"

	"github.com/quic-go/quic-go/http3"
	"github.com/stretchr/testify/require"

	"github.com/bluenviron/mediamtx/internal/protocols/httpp3"
	"github.com/bluenviron/mediamtx/internal/test"
)

func TestServer(t *testing.T) {
	// test that Server can be initialized and reached by a simple GET request
	s := &httpp3.Server{
		Address: "127.0.0.1:18443",
		Handler: http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
			w.WriteHeader(http.StatusOK)
		}),
		Parent: test.NilLogger,
	}
	err := s.Initialize()
	require.NoError(t, err)
	defer s.Close()

	tr := &http3.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true, //nolint:gosec
		},
	}
	defer tr.Close() //nolint:errcheck
	hc := &http.Client{Transport: tr}

	res, err := hc.Get("https://127.0.0.1:18443/")
	require.NoError(t, err)
	defer res.Body.Close()

	require.Equal(t, http.StatusOK, res.StatusCode)

	_, err = io.ReadAll(res.Body)
	require.NoError(t, err)
}
