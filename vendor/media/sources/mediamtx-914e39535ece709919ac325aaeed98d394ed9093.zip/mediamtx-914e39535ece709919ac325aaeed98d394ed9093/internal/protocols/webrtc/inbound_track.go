package webrtc

import (
	"crypto/rand"
	"time"

	"github.com/bluenviron/gortsplib/v5/pkg/rtpreceiver"
	"github.com/pion/rtcp"
	"github.com/pion/rtp"
	"github.com/pion/webrtc/v4"

	"github.com/bluenviron/mediamtx/internal/counterdumper"
	"github.com/bluenviron/mediamtx/internal/logger"
)

const (
	keyFrameInterval  = 2 * time.Second
	mimeTypeMultiopus = "audio/multiopus"
	mimeTypeL16       = "audio/L16"
)

var incomingVideoCodecs = []webrtc.RTPCodecParameters{
	{
		MimeType:    webrtc.MimeTypeAV1,
		ClockRate:   90000,
		SDPFmtpLine: "profile=1",
		PayloadType: 96,
	},
	{
		MimeType:    webrtc.MimeTypeAV1,
		ClockRate:   90000,
		PayloadType: 97,
	},
	{
		MimeType:    webrtc.MimeTypeVP9,
		ClockRate:   90000,
		SDPFmtpLine: "profile-id=3",
		PayloadType: 98,
	},
	{
		MimeType:    webrtc.MimeTypeVP9,
		ClockRate:   90000,
		SDPFmtpLine: "profile-id=2",
		PayloadType: 99,
	},
	{
		MimeType:    webrtc.MimeTypeVP9,
		ClockRate:   90000,
		SDPFmtpLine: "profile-id=1",
		PayloadType: 100,
	},
	{
		MimeType:    webrtc.MimeTypeVP9,
		ClockRate:   90000,
		SDPFmtpLine: "profile-id=0",
		PayloadType: 101,
	},
	{
		MimeType:    webrtc.MimeTypeVP8,
		ClockRate:   90000,
		PayloadType: 102,
	},
	{
		MimeType:    webrtc.MimeTypeH265,
		ClockRate:   90000,
		SDPFmtpLine: "level-id=93;profile-id=2;tier-flag=0;tx-mode=SRST",
		PayloadType: 103,
	},
	{
		MimeType:    webrtc.MimeTypeH265,
		ClockRate:   90000,
		SDPFmtpLine: "level-id=93;profile-id=1;tier-flag=0;tx-mode=SRST",
		PayloadType: 104,
	},
	{
		MimeType:    webrtc.MimeTypeH264,
		ClockRate:   90000,
		SDPFmtpLine: "level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42001f",
		PayloadType: 105,
	},
	{
		MimeType:    webrtc.MimeTypeH264,
		ClockRate:   90000,
		SDPFmtpLine: "level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f",
		PayloadType: 106,
	},
	// RTX (RFC 4588) companions for every video codec above. ConfigureNack()
	// only enables NACK handling; pion also needs an RTX codec registered for
	// each video codec before it can negotiate retransmissions. Payload types
	// must stay unique across both incomingVideoCodecs and incomingAudioCodecs,
	// so these use the remaining free slots in order.
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=96",
		PayloadType: 107,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=97",
		PayloadType: 108,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=98",
		PayloadType: 109,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=99",
		PayloadType: 110,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=100",
		PayloadType: 123,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=101",
		PayloadType: 124,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=102",
		PayloadType: 125,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=103",
		PayloadType: 126,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=104",
		PayloadType: 127,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=105",
		PayloadType: 35,
	},
	{
		MimeType:    webrtc.MimeTypeRTX,
		ClockRate:   90000,
		SDPFmtpLine: "apt=106",
		PayloadType: 36,
	},
}

var incomingAudioCodecs = []webrtc.RTPCodecParameters{
	{
		MimeType:    mimeTypeMultiopus,
		ClockRate:   48000,
		Channels:    3,
		SDPFmtpLine: "channel_mapping=0,2,1;num_streams=2;coupled_streams=1",
		PayloadType: 112,
	},
	{
		MimeType:    mimeTypeMultiopus,
		ClockRate:   48000,
		Channels:    4,
		SDPFmtpLine: "channel_mapping=0,1,2,3;num_streams=2;coupled_streams=2",
		PayloadType: 113,
	},
	{
		MimeType:    mimeTypeMultiopus,
		ClockRate:   48000,
		Channels:    5,
		SDPFmtpLine: "channel_mapping=0,4,1,2,3;num_streams=3;coupled_streams=2",
		PayloadType: 114,
	},
	{
		MimeType:    mimeTypeMultiopus,
		ClockRate:   48000,
		Channels:    6,
		SDPFmtpLine: "channel_mapping=0,4,1,2,3,5;num_streams=4;coupled_streams=2",
		PayloadType: 115,
	},
	{
		MimeType:    mimeTypeMultiopus,
		ClockRate:   48000,
		Channels:    7,
		SDPFmtpLine: "channel_mapping=0,4,1,2,3,5,6;num_streams=4;coupled_streams=4",
		PayloadType: 116,
	},
	{
		MimeType:    mimeTypeMultiopus,
		ClockRate:   48000,
		Channels:    8,
		SDPFmtpLine: "channel_mapping=0,6,1,4,5,2,3,7;num_streams=5;coupled_streams=4",
		PayloadType: 117,
	},
	{
		MimeType:    webrtc.MimeTypeOpus,
		ClockRate:   48000,
		Channels:    2,
		SDPFmtpLine: "minptime=10;useinbandfec=1;stereo=1;sprop-stereo=1",
		PayloadType: 111,
	},
	{
		MimeType:    webrtc.MimeTypeG722,
		ClockRate:   8000,
		PayloadType: 9,
	},
	{
		MimeType:    webrtc.MimeTypePCMU,
		ClockRate:   8000,
		Channels:    2,
		PayloadType: 118,
	},
	{
		MimeType:    webrtc.MimeTypePCMA,
		ClockRate:   8000,
		Channels:    2,
		PayloadType: 119,
	},
	{
		MimeType:    webrtc.MimeTypePCMU,
		ClockRate:   8000,
		PayloadType: 0,
	},
	{
		MimeType:    webrtc.MimeTypePCMA,
		ClockRate:   8000,
		PayloadType: 8,
	},
	{
		MimeType:    mimeTypeL16,
		ClockRate:   8000,
		Channels:    2,
		PayloadType: 120,
	},
	{
		MimeType:    mimeTypeL16,
		ClockRate:   16000,
		Channels:    2,
		PayloadType: 121,
	},
	{
		MimeType:    mimeTypeL16,
		ClockRate:   48000,
		Channels:    2,
		PayloadType: 122,
	},
}

func inboundTrackTWCCExtensionID(params webrtc.RTPParameters) uint8 {
	for _, ext := range params.HeaderExtensions {
		if ext.URI == twccExtensionURI {
			return uint8(ext.ID)
		}
	}
	return 0
}

func randUint16() (uint16, error) {
	var b [2]byte
	_, err := rand.Read(b[:])
	if err != nil {
		return 0, err
	}
	return uint16(b[0])<<8 | uint16(b[1]), nil
}

// InboundTrack is an incoming track.
type InboundTrack struct {
	OnPacketRTP func(*rtp.Packet)

	track     *webrtc.TrackRemote
	receiver  *webrtc.RTPReceiver
	midIndex  int
	rid       string
	ridIndex  int
	writeRTCP func([]rtcp.Packet) error
	log       logger.Writer

	twccExtID             uint8
	inboundRTPPacketsLost *counterdumper.Dumper
	rtpReceiver           *rtpreceiver.Receiver
}

func (t *InboundTrack) initialize() {
	t.OnPacketRTP = func(*rtp.Packet) {}
	t.twccExtID = inboundTrackTWCCExtensionID(t.receiver.GetParameters())
}

func (t *InboundTrack) stripTWCCExtension(pkt *rtp.Packet) {
	if t.twccExtID == 0 || pkt.GetExtension(t.twccExtID) == nil {
		return
	}

	err := pkt.DelExtension(t.twccExtID)
	if err != nil {
		panic(err)
	}

	if len(pkt.GetExtensionIDs()) == 0 {
		pkt.Extension = false
		pkt.ExtensionProfile = 0
	}
}

// Codec returns the track codec.
func (t *InboundTrack) Codec() webrtc.RTPCodecParameters {
	return t.track.Codec()
}

// ClockRate returns the clock rate. Needed by rtptime.GlobalDecoder
func (t *InboundTrack) ClockRate() int {
	return int(t.track.Codec().ClockRate)
}

// PTSEqualsDTS returns whether PTS equals DTS. Needed by rtptime.GlobalDecoder
func (*InboundTrack) PTSEqualsDTS(*rtp.Packet) bool {
	return true
}

func (t *InboundTrack) start() {
	t.inboundRTPPacketsLost = &counterdumper.Dumper{
		OnReport: func(val uint64) {
			t.log.Log(logger.Warn, "%d RTP %s lost",
				val,
				func() string {
					if val == 1 {
						return "packet"
					}
					return "packets"
				}())
		},
	}
	t.inboundRTPPacketsLost.Start()

	t.rtpReceiver = &rtpreceiver.Receiver{
		ClockRate:            int(t.track.Codec().ClockRate),
		UnrealiableTransport: true,
		Period:               1 * time.Second,
		WritePacketRTCP: func(p rtcp.Packet) {
			t.writeRTCP([]rtcp.Packet{p}) //nolint:errcheck
		},
	}
	err := t.rtpReceiver.Initialize()
	if err != nil {
		panic(err)
	}

	// read incoming RTCP packets.
	// incoming RTCP packets must always be read to make interceptors work.
	go func() {
		buf := make([]byte, 1500)
		for {
			n, _, err2 := t.receiver.ReadSimulcast(buf, t.rid)
			if err2 != nil {
				return
			}

			pkts, err2 := rtcp.Unmarshal(buf[:n])
			if err2 != nil {
				// it's currently impossible for this to be triggered,
				// because malformed RTCP packets are already blocked by pion/interceptor
				// and in particular by the NACK interceptor.
				panic(err2)
			}

			for _, pkt := range pkts {
				if sr, ok := pkt.(*rtcp.SenderReport); ok {
					t.rtpReceiver.ProcessSenderReport(sr, time.Now())
				}
			}
		}
	}()

	// send period key frame requests
	if t.track.Kind() == webrtc.RTPCodecTypeVideo {
		go func() {
			keyframeTicker := time.NewTicker(keyFrameInterval)
			defer keyframeTicker.Stop()

			for range keyframeTicker.C {
				err2 := t.writeRTCP([]rtcp.Packet{
					&rtcp.PictureLossIndication{
						MediaSSRC: uint32(t.track.SSRC()),
					},
				})
				if err2 != nil {
					return
				}
			}
		}()
	}

	// read incoming RTP packets.

	seqNumberOffset, err := randUint16()
	if err != nil {
		panic(err)
	}
	seqNumberOffsetInitialized := false

	go func() {
		for {
			pkt, _, err2 := t.track.ReadRTP()
			if err2 != nil {
				return
			}

			packets, lost := t.rtpReceiver.ProcessPacket2(pkt, time.Now(), true)

			if lost != 0 {
				t.inboundRTPPacketsLost.Add(lost)
				// do not return
			}

			for _, pkt := range packets {
				// sometimes Chrome sends empty RTP packets. ignore them.
				if len(pkt.Payload) == 0 {
					if seqNumberOffsetInitialized {
						seqNumberOffset--
					}
					continue
				}

				// recompute SequenceNumber, in order to account for the Chrome filtering above
				if !seqNumberOffsetInitialized {
					seqNumberOffset -= pkt.SequenceNumber
					seqNumberOffsetInitialized = true
				}
				pkt.SequenceNumber += seqNumberOffset

				t.stripTWCCExtension(pkt)
				t.OnPacketRTP(pkt)
			}
		}
	}()
}

// PacketNTP returns the packet NTP.
func (t *InboundTrack) PacketNTP(pkt *rtp.Packet) (time.Time, bool) {
	return t.rtpReceiver.PacketNTP(pkt.Timestamp)
}

func (t *InboundTrack) close() {
	if t.inboundRTPPacketsLost != nil {
		t.inboundRTPPacketsLost.Stop()
	}
	if t.rtpReceiver != nil {
		t.rtpReceiver.Close()
	}
}
