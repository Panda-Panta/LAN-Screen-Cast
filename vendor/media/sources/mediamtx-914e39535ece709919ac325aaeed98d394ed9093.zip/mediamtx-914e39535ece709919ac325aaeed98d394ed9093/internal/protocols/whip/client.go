// Package whip contains a WHIP/WHEP client.
package whip

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/pion/sdp/v3"
	pwebrtc "github.com/pion/webrtc/v4"

	"github.com/bluenviron/mediamtx/internal/logger"
	"github.com/bluenviron/mediamtx/internal/protocols/httpp"
	"github.com/bluenviron/mediamtx/internal/protocols/webrtc"
)

const (
	maxInboundSDPSize = 128 * 1024
)

func whipAnswer(body []byte) *pwebrtc.SessionDescription {
	return &pwebrtc.SessionDescription{
		Type: pwebrtc.SDPTypeAnswer,
		SDP:  string(body),
	}
}

func offerAndCandidateToSDPFragment(
	offer *pwebrtc.SessionDescription,
	candidate *pwebrtc.ICECandidateInit,
) (*SDPFragment, error) {
	f := &SDPFragment{}

	var desc sdp.SessionDescription
	err := desc.Unmarshal([]byte(offer.SDP))
	if err != nil {
		return nil, err
	}

	if candidate.SDPMLineIndex == nil {
		return nil, fmt.Errorf("sdpMLineIndex is null")
	}

	if len(desc.MediaDescriptions) < int(*candidate.SDPMLineIndex)+1 {
		return nil, fmt.Errorf("sdpMLineIndex is out of range")
	}

	media := desc.MediaDescriptions[*candidate.SDPMLineIndex]

	iceUFrag, _ := media.Attribute("ice-ufrag")
	icePwd, _ := media.Attribute("ice-pwd")

	if iceUFrag == "" || icePwd == "" {
		return nil, fmt.Errorf("ice-ufrag or ice-pwd are missing in the media of the candidate")
	}

	f.Medias = append(f.Medias, &sdp.MediaDescription{
		MediaName: media.MediaName,
		Attributes: []sdp.Attribute{
			{Key: "mid", Value: strconv.FormatUint(uint64(*candidate.SDPMLineIndex), 10)},
			{Key: "ice-ufrag", Value: iceUFrag},
			{Key: "ice-pwd", Value: icePwd},
			{Key: "candidate", Value: candidate.Candidate},
		},
	})

	return f, nil
}

// Client is a WHIP client.
type Client struct {
	URL                  *url.URL
	Publish              bool
	OutboundTracks       []*webrtc.OutboundTrack
	OutboundDataChannels []*webrtc.OutboundDataChannel
	HTTPClient           *http.Client
	BearerToken          string
	UDPReadBufferSize    uint
	SupportsIPv6         bool
	STUNGatherTimeout    time.Duration
	HandshakeTimeout     time.Duration
	TrackGatherTimeout   time.Duration
	Log                  logger.Writer

	pc            *webrtc.PeerConnection
	useTrickleICE bool
}

// Initialize initializes the Client.
func (c *Client) Initialize(ctx context.Context) error {
	if c.STUNGatherTimeout == 0 {
		c.STUNGatherTimeout = 5 * time.Second
	}
	if c.HandshakeTimeout == 0 {
		c.HandshakeTimeout = 10 * time.Second
	}
	if c.TrackGatherTimeout == 0 {
		c.TrackGatherTimeout = 2 * time.Second
	}

	iceServers, err := c.optionsICEServers(ctx)
	if err != nil {
		return err
	}

	c.pc = &webrtc.PeerConnection{
		Net:                  &webrtc.Net{UDPReadBufferSize: int(c.UDPReadBufferSize)},
		LocalRandomUDP:       true,
		SupportsIPv6:         c.SupportsIPv6,
		ICEServers:           iceServers,
		IPsFromInterfaces:    true,
		Publish:              c.Publish,
		STUNGatherTimeout:    c.STUNGatherTimeout,
		OutboundTracks:       c.OutboundTracks,
		OutboundDataChannels: c.OutboundDataChannels,
		Log:                  c.Log,
	}
	err = c.pc.Start()
	if err != nil {
		return err
	}

	initializeRes := make(chan error)

	go func() {
		initializeRes <- c.initializeInner(ctx)
	}()

	select {
	case <-ctx.Done():
		c.pc.Close()
		<-initializeRes
		return fmt.Errorf("terminated")

	case err = <-initializeRes:
	}

	if err != nil {
		c.pc.Close()
		return err
	}

	return nil
}

func (c *Client) initializeInner(ctx context.Context) error {
	var offer *pwebrtc.SessionDescription
	if c.useTrickleICE {
		var err error
		offer, err = c.pc.CreatePartialOffer(false)
		if err != nil {
			return err
		}
	} else {
		var err error
		offer, err = c.pc.CreateFullOffer()
		if err != nil {
			return err
		}
	}

	res, err := c.postOffer(ctx, offer)
	if err != nil {
		return err
	}

	c.URL, err = c.URL.Parse(res.Location)
	if err != nil {
		return err
	}

	if !c.Publish {
		var sdp sdp.SessionDescription
		err = sdp.Unmarshal([]byte(res.Answer.SDP))
		if err != nil {
			c.deleteSession(context.Background()) //nolint:errcheck
			return err
		}

		err = webrtc.TracksAreValid(sdp.MediaDescriptions)
		if err != nil {
			c.deleteSession(context.Background()) //nolint:errcheck
			return err
		}
	}

	err = c.pc.SetAnswer(res.Answer)
	if err != nil {
		c.deleteSession(context.Background()) //nolint:errcheck
		return err
	}

	err = c.waitConnected(ctx, offer, res.ETag)
	if err != nil {
		c.deleteSession(context.Background()) //nolint:errcheck
		return err
	}

	if !c.Publish {
		err = c.pc.GatherInboundTracks(c.TrackGatherTimeout)
		if err != nil {
			c.deleteSession(context.Background()) //nolint:errcheck
			return err
		}
	}

	return nil
}

func (c *Client) waitConnected(ctx context.Context, offer *pwebrtc.SessionDescription, eTag string) error {
	t := time.NewTimer(c.HandshakeTimeout)
	defer t.Stop()

	if c.useTrickleICE {
		for {
			select {
			case ca := <-c.pc.NewLocalCandidate():
				err := c.patchCandidate(ctx, offer, eTag, ca)
				if err != nil {
					return err
				}

			case <-c.pc.Connected():
				return nil

			case <-t.C:
				return fmt.Errorf("deadline exceeded while waiting connection")
			}
		}
	}

	for {
		select {
		case <-c.pc.Connected():
			return nil

		case <-t.C:
			return fmt.Errorf("deadline exceeded while waiting connection")
		}
	}
}

// PeerConnection returns the underlying peer connection.
func (c *Client) PeerConnection() *webrtc.PeerConnection {
	return c.pc
}

// InboundTracks returns incoming tracks.
func (c *Client) InboundTracks() []*webrtc.InboundTrack {
	return c.pc.InboundTracks()
}

// StartReading starts reading all incoming tracks.
func (c *Client) StartReading() {
	c.pc.StartReading()
}

// Close closes the client.
func (c *Client) Close() error {
	err := c.deleteSession(context.Background())
	c.pc.Close()
	return err
}

// Wait waits until a fatal error occurs.
func (c *Client) Wait() error {
	<-c.pc.Failed()
	return fmt.Errorf("peer connection closed")
}

func (c *Client) optionsICEServers(
	ctx context.Context,
) ([]pwebrtc.ICEServer, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodOptions, c.URL.String(), nil)
	if err != nil {
		return nil, err
	}

	if c.BearerToken != "" {
		req.Header.Set("Authorization", "Bearer "+c.BearerToken)
	}

	res, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()

	if res.StatusCode != http.StatusOK && res.StatusCode != http.StatusNoContent {
		return nil, fmt.Errorf("bad status code: %v", res.StatusCode)
	}

	for m := range strings.SplitSeq(res.Header.Get("Access-Control-Allow-Methods"), ",") {
		if strings.TrimSpace(m) == "PATCH" {
			c.useTrickleICE = true
			break
		}
	}

	var lh LinkHeader
	err = lh.Unmarshal(res.Header["Link"])
	if err != nil {
		return nil, err
	}
	return []pwebrtc.ICEServer(lh), nil
}

type whipPostOfferResponse struct {
	Answer   *pwebrtc.SessionDescription
	Location string
	ETag     string
}

func (c *Client) postOffer(
	ctx context.Context,
	offer *pwebrtc.SessionDescription,
) (*whipPostOfferResponse, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.URL.String(), bytes.NewReader([]byte(offer.SDP)))
	if err != nil {
		return nil, err
	}

	if c.BearerToken != "" {
		req.Header.Set("Authorization", "Bearer "+c.BearerToken)
	}

	req.Header.Set("Content-Type", "application/sdp")

	res, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()

	if res.StatusCode != http.StatusCreated {
		return nil, fmt.Errorf("bad status code: %v", res.StatusCode)
	}

	contentType := httpp.ParseContentType(res.Header.Get("Content-Type"))
	if contentType != "application/sdp" {
		return nil, fmt.Errorf("bad Content-Type: expected 'application/sdp', got '%s'", contentType)
	}

	Location := res.Header.Get("Location")

	var etag string
	if c.useTrickleICE {
		etag = res.Header.Get("ETag")
		if etag == "" {
			return nil, fmt.Errorf("ETag is missing")
		}
	}

	sdp, err := io.ReadAll(&customLimitReader{res.Body, maxInboundSDPSize})
	if err != nil {
		return nil, err
	}

	return &whipPostOfferResponse{
		Answer:   whipAnswer(sdp),
		Location: Location,
		ETag:     etag,
	}, nil
}

func (c *Client) patchCandidate(
	ctx context.Context,
	offer *pwebrtc.SessionDescription,
	etag string,
	candidate *pwebrtc.ICECandidateInit,
) error {
	frag, err := offerAndCandidateToSDPFragment(offer, candidate)
	if err != nil {
		return err
	}

	enc, err := frag.Marshal()
	if err != nil {
		return err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPatch, c.URL.String(), bytes.NewReader(enc))
	if err != nil {
		return err
	}

	if c.BearerToken != "" {
		req.Header.Set("Authorization", "Bearer "+c.BearerToken)
	}

	req.Header.Set("Content-Type", "application/trickle-ice-sdpfrag")
	req.Header.Set("If-Match", etag)

	res, err := c.HTTPClient.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()

	if res.StatusCode != http.StatusNoContent {
		return fmt.Errorf("bad status code: %v", res.StatusCode)
	}

	return nil
}

func (c *Client) deleteSession(
	ctx context.Context,
) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodDelete, c.URL.String(), nil)
	if err != nil {
		return err
	}

	if c.BearerToken != "" {
		req.Header.Set("Authorization", "Bearer "+c.BearerToken)
	}

	res, err := c.HTTPClient.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()

	if res.StatusCode != http.StatusOK {
		return fmt.Errorf("bad status code: %v", res.StatusCode)
	}

	return nil
}
